cd /d "%~dp0"
rundll32 .\yong.dll Unreg
del /F %windir%\system32\yong-bak.ime
del /F %windir%\system32\yong.ime
del /F %windir%\sysWOW64\yong-bak.ime
del /F %windir%\sysWOW64\yong.ime
