cd /d "%~dp0"
rundll32 .\yong.dll,Reg
