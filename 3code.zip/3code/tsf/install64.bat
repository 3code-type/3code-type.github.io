cd /d "%~dp0"
tsf-reg.exe -i
tsf-reg64.exe -i

