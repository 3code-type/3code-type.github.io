cd /d "%~dp0"

tsf-reg.exe -i

if %PROCESSOR_ARCHITECTURE%==x86 goto end 
	tsf-reg64.exe -i
:end
