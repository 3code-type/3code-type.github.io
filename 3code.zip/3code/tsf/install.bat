cd /d "%~dp0"
tsf-reg.exe -i
