cd /d "%~dp0"
tsf-reg.exe -u -d

