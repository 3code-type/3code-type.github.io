cd /d "%~dp0"
tsf-reg64.exe -u -d
tsf-reg.exe -u -d
